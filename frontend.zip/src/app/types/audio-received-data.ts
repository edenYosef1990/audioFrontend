export interface AudioReceivedData {
    audio: Uint8Array;
}